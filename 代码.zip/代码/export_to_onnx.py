import torch
import torch.nn as nn
import numpy as np
import onnxruntime
import math
from collections import OrderedDict
import scipy.io  # 导入用于加载 .mat 文件的库
import os
import torch.nn.functional as F
# --- 为了让脚本可以独立运行，这里包含了模型定义的全部代码 ---
from torch import Tensor
from einops import rearrange
from einops.layers.torch import Rearrange


class PatchEmbedding(nn.Module):
    def __init__(self, emb_size=40, num_channels=22):
        super().__init__()
        self.num_channels = num_channels
        self.shallownet = nn.Sequential(
            nn.Conv2d(1, 40, (1, 25), (1, 1)),
            nn.Conv2d(40, 40, (self.num_channels, 1), (1, 1)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.AvgPool2d((1, 75), (1, 15)),
            nn.Dropout(0.5),
        )

        self.projection = nn.Sequential(
            nn.Conv2d(40, emb_size, (1, 1), stride=(1, 1)),
            Rearrange('b e 1 w -> b w e'),
        )

    def forward(self, x: Tensor) -> Tensor:
        b, _, _, _ = x.shape
        x = self.shallownet(x)
        x = self.projection(x)
        return x


class MultiHeadAttention(nn.Module):
    def __init__(self, emb_size, num_heads, dropout):
        super().__init__()
        self.emb_size = emb_size
        self.num_heads = num_heads
        self.keys = nn.Linear(emb_size, emb_size)
        self.queries = nn.Linear(emb_size, emb_size)
        self.values = nn.Linear(emb_size, emb_size)
        self.att_drop = nn.Dropout(dropout)
        self.projection = nn.Linear(emb_size, emb_size)

    def forward(self, x: Tensor, mask: Tensor = None) -> Tensor:
        queries = rearrange(self.queries(x), "b n (h d) -> b h n d", h=self.num_heads)
        keys = rearrange(self.keys(x), "b n (h d) -> b h n d", h=self.num_heads)
        values = rearrange(self.values(x), "b n (h d) -> b h n d", h=self.num_heads)
        energy = torch.einsum('bhqd, bhkd -> bhqk', queries, keys)
        if mask is not None:
            fill_value = torch.finfo(torch.float32).min
            energy.mask_fill(~mask, fill_value)

        scaling = self.emb_size ** (1 / 2)
        att = F.softmax(energy / scaling, dim=-1)
        att = self.att_drop(att)
        out = torch.einsum('bhal, bhlv -> bhav ', att, values)
        out = rearrange(out, "b h n d -> b n (h d)")
        out = self.projection(out)
        return out


class ResidualAdd(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        res = x
        x = self.fn(x, **kwargs)
        x += res
        return x


class FeedForwardBlock(nn.Sequential):
    def __init__(self, emb_size, expansion, drop_p):
        super().__init__(
            nn.Linear(emb_size, expansion * emb_size),
            nn.GELU(),
            nn.Dropout(drop_p),
            nn.Linear(expansion * emb_size, emb_size),
        )


class GELU(nn.Module):
    def forward(self, input: Tensor) -> Tensor:
        return input * 0.5 * (1.0 + torch.erf(input / math.sqrt(2.0)))


class TransformerEncoderBlock(nn.Sequential):
    def __init__(self,
                 emb_size,
                 num_heads=5,
                 drop_p=0.5,
                 forward_expansion=4,
                 forward_drop_p=0.5):
        super().__init__(
            ResidualAdd(nn.Sequential(
                nn.LayerNorm(emb_size),
                MultiHeadAttention(emb_size, num_heads, drop_p),
                nn.Dropout(drop_p)
            )),
            ResidualAdd(nn.Sequential(
                nn.LayerNorm(emb_size),
                FeedForwardBlock(
                    emb_size, expansion=forward_expansion, drop_p=forward_drop_p),
                nn.Dropout(drop_p)
            )
            ))


class TransformerEncoder(nn.Sequential):
    def __init__(self, depth, emb_size):
        super().__init__(*[TransformerEncoderBlock(emb_size) for _ in range(depth)])


class ClassificationHead(nn.Sequential):
    def __init__(self, emb_size, n_classes=4):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(2440, 256),
            nn.ELU(),
            nn.Dropout(0.5),
            nn.Linear(256, 32),
            nn.ELU(),
            nn.Dropout(0.3),
            nn.Linear(32, n_classes)
        )
    # --- 保持 ClassificationHead 的 forward 只返回 out ---
    def forward(self, x):
        x = x.contiguous().view(x.size(0), -1)
        out = self.fc(x)
        return out


class ViT(nn.Sequential):
    def __init__(self, num_channels=22, n_classes=4, emb_size=40, depth=10, **kwargs):
        super().__init__(
            PatchEmbedding(emb_size, num_channels),
            TransformerEncoder(depth, emb_size),
            ClassificationHead(emb_size, n_classes)
        )


# --- 模型定义结束 ---


def main():
    # --- 1. 配置区域 ---
    PTH_MODEL_PATH = './best_model_sub1.pth'
    ONNX_EXPORT_PATH = 'eeg_conformer.fp32.onnx'
    MAT_TEST_FILE_PATH = 'D:/FPGA-EEG/dataset/MI/A01E.mat'

    NUM_CHANNELS = 22
    N_CLASSES = 4

    # ==========================  在此处填入数值  ==========================
    # !! 关键 !!
    # !! 您必须从第一个训练脚本的输出中找到 subject 1 的均值和标准差 !!
    # !! 并将它们粘贴到下面，替换 0.0 和 1.0 !!
    TRAIN_MEAN = -0.004831738  # <-- 替换成您的真实均值 (例如: 0.00345)
    TRAIN_STD = 5.3116633  # <-- 替换成您的真实标准差 (例如: 4.56789)
    # ====================================================================

    if TRAIN_STD == 1.0:
        print("警告: TRAIN_STD 仍为 1.0。请确保您已从训练脚本中填入了正确的均值和标准差。")


    # --- 2. 加载PyTorch模型并导出 ---
    print(f"准备加载模型: {PTH_MODEL_PATH}")
    pytorch_model = ViT(num_channels=NUM_CHANNELS, n_classes=N_CLASSES)
    state_dict = torch.load(PTH_MODEL_PATH, map_location='cpu')
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith('module.') else k
        new_state_dict[name] = v
    pytorch_model.load_state_dict(new_state_dict)
    pytorch_model.eval()
    print("模型加载成功。")

    dummy_input = torch.randn(1, 1, NUM_CHANNELS, 1000)
    print("\n开始导出ONNX模型...")
    torch.onnx.export(pytorch_model, dummy_input, ONNX_EXPORT_PATH, export_params=True, opset_version=12,
                      do_constant_folding=True, input_names=['input'], output_names=['output'],
                      dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}})
    print(f"ONNX模型导出成功！已保存至: {ONNX_EXPORT_PATH}")

    # --- 3. 使用真实数据进行验证 ---
    print("\n--- 开始使用真实测试集数据进行数值一致性验证 ---")
    try:
        print("加载ONNX模型到ONNX Runtime...")
        ort_session = onnxruntime.InferenceSession(ONNX_EXPORT_PATH, providers=['CPUExecutionProvider'])
        print("ONNX Runtime会话创建成功。")

        print(f"正在加载测试集文件: {MAT_TEST_FILE_PATH}")
        if not os.path.exists(MAT_TEST_FILE_PATH):
            raise FileNotFoundError(f"测试集文件未找到: {MAT_TEST_FILE_PATH}")

        mat_data = scipy.io.loadmat(MAT_TEST_FILE_PATH)

        # 加载真实标签 (1-4 -> 0-3)
        eeg_labels = mat_data['label'].flatten() - 1

        # 加载并转置数据
        # 保持正确的转置 (2, 0, 1) -> (N, 22, 1000)
        eeg_data = mat_data['data'].transpose(2, 1, 0)
        eeg_data = np.expand_dims(eeg_data, axis=1)  # -> (N, 1, 22, 1000)

        # ==========================  应用标准化（关键修正） ==========================
        print(f"正在应用标准化: Mean={TRAIN_MEAN}, Std={TRAIN_STD}")
        # 确保 eeg_data 是浮点数以便进行除法
        eeg_data = eeg_data.astype(np.float32)
        eeg_data = (eeg_data - TRAIN_MEAN) / TRAIN_STD
        # =========================================================================

        test_data_tensor = torch.from_numpy(eeg_data).float()
        print(f"成功加载并处理了 {len(test_data_tensor)} 个测试样本。")

        # 循环验证前5个样本 (保持不变)
        num_samples_to_check = 5
        print(f"\n--- 逐一对比前 {num_samples_to_check} 个样本的输出 ---")
        for i in range(num_samples_to_check):
            print(f"\n--- [ 正在检验样本 {i} ] ---")
            sample_tensor = test_data_tensor[i:i + 1]
            print(f"即将送入模型的张量 'sample_tensor' 的真实形状是: {sample_tensor.shape}")

            with torch.no_grad():
                pytorch_output = pytorch_model(sample_tensor).cpu().numpy()
            input_name = ort_session.get_inputs()[0].name
            onnx_output = ort_session.run(None, {input_name: sample_tensor.cpu().numpy()})[0]

            print("PyTorch输出: ", pytorch_output.flatten())
            print("ONNX输出:    ", onnx_output.flatten())

            np.testing.assert_allclose(pytorch_output, onnx_output, rtol=1e-03, atol=1e-05)
            print("✅ 数值一致性检查通过！")

        print(f"\n\n✅✅✅ 最终验证成功！前 {num_samples_to_check} 个真实样本的输出在PyTorch和ONNX Runtime之间完全一致！✅✅✅")

        # --- 新增改动 2: 在完整测试集上评估准确率 ---
        print("\n--- 开始在完整测试集上评估准确率 ---")

        # 1. PyTorch模型对整个测试集进行推理
        print("正在使用PyTorch模型进行推理...")
        with torch.no_grad():
            pytorch_full_output = pytorch_model(test_data_tensor)
            # 从输出的logits中找到最大值的索引，即为预测的类别
            pytorch_preds = torch.argmax(pytorch_full_output, dim=1).cpu().numpy()

        # 2. ONNX Runtime模型对整个测试集进行推理
        print("正在使用ONNX Runtime进行推理...")
        input_name = ort_session.get_inputs()[0].name
        # 注意：这里需要传入 eeg_data (numpy 数组)，而不是 test_data_tensor
        onnx_full_output = ort_session.run(None, {input_name: eeg_data})[0]
        # 同样，找到最大值的索引作为预测类别
        onnx_preds = np.argmax(onnx_full_output, axis=1)

        # 3. 计算并打印准确率
        pytorch_accuracy = np.mean(pytorch_preds == eeg_labels)
        onnx_accuracy = np.mean(onnx_preds == eeg_labels)

        print("\n--- 准确率计算结果 ---")
        print(f"真实标签样本数量: {len(eeg_labels)}")
        print(f"PyTorch 预测样本数量: {len(pytorch_preds)}")
        print(f"ONNX 预测样本数量: {len(onnx_preds)}")
        # 使用 .4f 格式化输出为4位小数
        print(
            f"✅ PyTorch 模型准确率: {pytorch_accuracy:.4f} ({np.sum(pytorch_preds == eeg_labels)} / {len(eeg_labels)})")
        print(f"✅ ONNX 模型准确率:    {onnx_accuracy:.4f} ({np.sum(onnx_preds == eeg_labels)} / {len(eeg_labels)})")

        # 最终确认两个模型的预测结果是否完全一致
        if np.array_equal(pytorch_preds, onnx_preds):
            print("\n✅ 两个模型的预测结果完全一致！")
        else:
            print("\n❌ 警告：两个模型的预测结果存在差异！")

    except Exception as e:
        print(f"\n❌❌❌ 验证失败！❌❌❌")
        print(f"错误信息: {e}")


if __name__ == '__main__':
    main()