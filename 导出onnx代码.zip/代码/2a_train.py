"""
EEG conformer
Test on the datasets 2a
Version 3.0: Implemented a robust train/validation/test split
"""

import argparse
import os

gpus = [0]  # 你可以根据你的GPU情况修改
os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'
os.environ["CUDA_VISIBLE_DEVICES"] = ','.join(map(str, gpus))
import numpy as np
import math
import glob
import random
import itertools
import datetime
import time
import datetime
import sys
import scipy.io
from sklearn.model_selection import train_test_split  ## 新增 ##: 导入数据划分工具

import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid

from torch.utils.data import DataLoader
from torch.autograd import Variable
from torchsummary import summary
import torch.autograd as autograd
from torchvision.models import vgg19

import torch.nn as nn
import torch.nn.functional as F
import torch
import torch.nn.init as init

from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms
from sklearn.decomposition import PCA

import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt

from torch import nn
from torch import Tensor
from PIL import Image
from torchvision.transforms import Compose, Resize, ToTensor
from einops import rearrange, reduce, repeat
from einops.layers.torch import Rearrange, Reduce
# from common_spatial_pattern import csp

import matplotlib.pyplot as plt
# from torch.utils.tensorboard import SummaryWriter
from torch.backends import cudnn

cudnn.benchmark = False
cudnn.deterministic = True


# --- 模型架构部分 (与之前版本相同，保持不变) ---
class PatchEmbedding(nn.Module):
    def __init__(self, emb_size=40, num_channels=22):
        super().__init__()
        self.num_channels = num_channels
        self.shallownet = nn.Sequential(
            nn.Conv2d(1, 40, (1, 25), (1, 1)),
            nn.Conv2d(40, 40, (self.num_channels, 1), (1, 1)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.AvgPool2d((1, 75), (1, 15)),
            nn.Dropout(0.5),
        )

        self.projection = nn.Sequential(
            nn.Conv2d(40, emb_size, (1, 1), stride=(1, 1)),
            Rearrange('b e 1 w -> b w e'),
        )

    def forward(self, x: Tensor) -> Tensor:
        b, _, _, _ = x.shape
        x = self.shallownet(x)
        x = self.projection(x)
        return x


class MultiHeadAttention(nn.Module):
    def __init__(self, emb_size, num_heads, dropout):
        super().__init__()
        self.emb_size = emb_size
        self.num_heads = num_heads
        self.keys = nn.Linear(emb_size, emb_size)
        self.queries = nn.Linear(emb_size, emb_size)
        self.values = nn.Linear(emb_size, emb_size)
        self.att_drop = nn.Dropout(dropout)
        self.projection = nn.Linear(emb_size, emb_size)

    def forward(self, x: Tensor, mask: Tensor = None) -> Tensor:
        queries = rearrange(self.queries(x), "b n (h d) -> b h n d", h=self.num_heads)
        keys = rearrange(self.keys(x), "b n (h d) -> b h n d", h=self.num_heads)
        values = rearrange(self.values(x), "b n (h d) -> b h n d", h=self.num_heads)
        energy = torch.einsum('bhqd, bhkd -> bhqk', queries, keys)
        if mask is not None:
            fill_value = torch.finfo(torch.float32).min
            energy.mask_fill(~mask, fill_value)

        scaling = self.emb_size ** (1 / 2)
        att = F.softmax(energy / scaling, dim=-1)
        att = self.att_drop(att)
        out = torch.einsum('bhal, bhlv -> bhav ', att, values)
        out = rearrange(out, "b h n d -> b n (h d)")
        out = self.projection(out)
        return out


class ResidualAdd(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        res = x
        x = self.fn(x, **kwargs)
        x += res
        return x


class FeedForwardBlock(nn.Sequential):
    def __init__(self, emb_size, expansion, drop_p):
        super().__init__(
            nn.Linear(emb_size, expansion * emb_size),
            nn.GELU(),
            nn.Dropout(drop_p),
            nn.Linear(expansion * emb_size, emb_size),
        )


class GELU(nn.Module):
    def forward(self, input: Tensor) -> Tensor:
        return input * 0.5 * (1.0 + torch.erf(input / math.sqrt(2.0)))


class TransformerEncoderBlock(nn.Sequential):
    def __init__(self,
                 emb_size,
                 num_heads=5,
                 drop_p=0.5,
                 forward_expansion=4,
                 forward_drop_p=0.5):
        super().__init__(
            ResidualAdd(nn.Sequential(
                nn.LayerNorm(emb_size),
                MultiHeadAttention(emb_size, num_heads, drop_p),
                nn.Dropout(drop_p)
            )),
            ResidualAdd(nn.Sequential(
                nn.LayerNorm(emb_size),
                FeedForwardBlock(
                    emb_size, expansion=forward_expansion, drop_p=forward_drop_p),
                nn.Dropout(drop_p)
            )
            ))


class TransformerEncoder(nn.Sequential):
    def __init__(self, depth, emb_size):
        super().__init__(*[TransformerEncoderBlock(emb_size) for _ in range(depth)])


class ClassificationHead(nn.Sequential):
    def __init__(self, emb_size, n_classes=4):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(2440, 256),
            nn.ELU(),
            nn.Dropout(0.5),
            nn.Linear(256, 32),
            nn.ELU(),
            nn.Dropout(0.3),
            nn.Linear(32, n_classes)
        )

    def forward(self, x):
        x = x.contiguous().view(x.size(0), -1)
        out = self.fc(x)
        return x, out


class ViT(nn.Sequential):
    def __init__(self, num_channels=22, n_classes=4, emb_size=40, depth=10, **kwargs):
        super().__init__(
            PatchEmbedding(emb_size, num_channels),
            TransformerEncoder(depth, emb_size),
            ClassificationHead(emb_size, n_classes)
        )


# --- 模型架构部分结束 ---


class Trainer():
    def __init__(self, nsub):
        super(Trainer, self).__init__()
        self.batch_size = 50
        self.n_epochs = 200

        self.channels = 22
        self.n_classes = 4
        self.img_width = 1000

        self.lr = 0.0002
        self.b1 = 0.5
        self.b2 = 0.999

        self.nSub = nsub

        self.root = 'D:/FPGA-EEG/dataset/MI/'
        self.log_write = open(f"./log_subject_{self.nSub}.txt", "w")

        self.Tensor = torch.cuda.FloatTensor
        self.LongTensor = torch.cuda.LongTensor

        self.criterion_cls = torch.nn.CrossEntropyLoss().cuda()

        self.model = ViT(num_channels=self.channels, n_classes=self.n_classes).cuda()
        self.model = nn.DataParallel(self.model, device_ids=[i for i in range(len(gpus))])
        self.model = self.model.cuda()

    def interaug(self, timg, label):
        aug_data = []
        aug_label = []
        for cls4aug in range(self.n_classes):
            # 注意: 这里的标签应为0-3范围
            cls_idx = np.where(label == cls4aug)[0]
            if len(cls_idx) == 0: continue

            tmp_data = timg[cls_idx]
            num_aug_samples = int(self.batch_size / self.n_classes)
            if num_aug_samples == 0: continue

            tmp_aug_data = np.zeros((num_aug_samples, 1, self.channels, self.img_width))

            for i in range(num_aug_samples):
                idx1, idx2 = np.random.choice(len(tmp_data), 2, replace=False)
                sample1, sample2 = tmp_data[idx1], tmp_data[idx2]
                alpha = np.random.rand()
                new_sample = alpha * sample1 + (1 - alpha) * sample2
                tmp_aug_data[i] = new_sample

            aug_data.append(tmp_aug_data)
            aug_label.append(np.full(num_aug_samples, cls4aug))

        if not aug_data: return None, None

        aug_data = np.concatenate(aug_data)
        aug_label = np.concatenate(aug_label)
        aug_shuffle = np.random.permutation(len(aug_data))
        aug_data = aug_data[aug_shuffle]
        aug_label = aug_label[aug_shuffle]

        aug_data = torch.from_numpy(aug_data).cuda().float()
        aug_label = torch.from_numpy(aug_label).cuda().long()
        return aug_data, aug_label

    def get_source_data(self):
        # 加载训练数据 (A0*T.mat)
        train_path = os.path.join(self.root, f'A0{self.nSub}T.mat')
        train_mat = scipy.io.loadmat(train_path)
        train_data = train_mat['data']
        train_data = np.transpose(train_data, (2, 1, 0))
        train_data = np.expand_dims(train_data, axis=1)
        train_label = train_mat['label'].flatten()

        # 加载用于分割的 E 文件 (A0*E.mat)
        test_val_path = os.path.join(self.root, f'A0{self.nSub}E.mat')
        test_val_mat = scipy.io.loadmat(test_val_path)
        test_val_data = test_val_mat['data']
        test_val_data = np.transpose(test_val_data, (2, 1, 0))
        test_val_data = np.expand_dims(test_val_data, axis=1)
        test_val_label = test_val_mat['label'].flatten()

        # 标准化 (使用训练集的均值和标准差)
        train_mean = np.mean(train_data)
        train_std = np.std(train_data)
        # --- 添加这两行来打印数值 ---
        print(f"!!! 找到数值 !!!")
        print(f"训练集均值 (train_mean): {train_mean}")
        print(f"训练集标准差 (train_std): {train_std}")
        # --------------------------
        train_data = (train_data - train_mean) / train_std
        test_val_data = (test_val_data - train_mean) / train_std


        return train_data, train_label, test_val_data, test_val_label

    def train(self):
        ## 修改部分 ##: 整个函数逻辑重构以实现 训练/验证/测试 的划分

        # 1. 加载数据
        train_data, train_label, test_val_data, test_val_label = self.get_source_data()

        # 2. 将 E 文件数据对半分割成验证集和真正的测试集
        # stratify 参数保证分割后，验证集和测试集的类别比例与原始E文件一致
        val_data, test_data, val_label, test_label = train_test_split(
            test_val_data, test_val_label, test_size=0.5, random_state=42, stratify=test_val_label
        )
        print(
            f"Data split for Sub {self.nSub}: {len(train_data)} train, {len(val_data)} validation, {len(test_data)} test samples.")

        # 3. 准备 PyTorch 数据集和加载器
        # 将所有标签从 1-4 转换为 0-3
        train_label, val_label, test_label = train_label - 1, val_label - 1, test_label - 1

        # 训练集 DataLoader
        train_dataset = torch.utils.data.TensorDataset(torch.from_numpy(train_data), torch.from_numpy(train_label))
        self.dataloader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=self.batch_size, shuffle=True)

        # 验证集和测试集转换为 Tensor
        val_data_tensor = Variable(torch.from_numpy(val_data).type(self.Tensor))
        val_label_tensor = Variable(torch.from_numpy(val_label).type(self.LongTensor))
        test_data_tensor = Variable(torch.from_numpy(test_data).type(self.Tensor))
        test_label_tensor = Variable(torch.from_numpy(test_label).type(self.LongTensor))

        # 4. 定义优化器
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr, betas=(self.b1, self.b2))

        best_val_acc = 0
        best_model_path = f'./best_model_sub{self.nSub}.pth'

        # 5. 训练循环
        for e in range(self.n_epochs):
            self.model.train()
            for i, (img_batch, label_batch) in enumerate(self.dataloader):
                img_batch = Variable(img_batch.cuda().type(self.Tensor))
                label_batch = Variable(label_batch.cuda().type(self.LongTensor))

                # 数据增强只在训练集上进行，注意传入的标签是0-3
                aug_data, aug_label = self.interaug(train_data, train_label)
                if aug_data is not None:
                    final_img = torch.cat((img_batch, aug_data))
                    final_label = torch.cat((label_batch, aug_label))
                else:
                    final_img, final_label = img_batch, label_batch

                _, outputs = self.model(final_img)
                loss = self.criterion_cls(outputs, final_label)

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

            # 6. 在验证集上评估并保存最佳模型
            self.model.eval()
            with torch.no_grad():
                _, Cls = self.model(val_data_tensor)
                loss_val = self.criterion_cls(Cls, val_label_tensor)
                y_pred_tensor = torch.max(Cls, 1)[1]
                val_acc = float((y_pred_tensor == val_label_tensor).cpu().numpy().astype(int).sum()) / float(
                    val_label_tensor.size(0))

                print(
                    f'Epoch: {e}, Train loss: {loss.item():.6f}, Val loss: {loss_val.item():.6f}, Val accuracy is {val_acc:.6f}')
                self.log_write.write(f"{e}\t{val_acc}\n")

                if val_acc > best_val_acc:
                    best_val_acc = val_acc
                    torch.save(self.model.state_dict(), best_model_path)
                    print(f"New best validation accuracy: {best_val_acc:.6f}. Model saved.")

        # 7. 训练结束后，在最终测试集上进行一次性评估
        print("\n--- Final testing on the held-out test set ---")
        # 加载在验证集上表现最好的模型
        self.model.load_state_dict(torch.load(best_model_path))
        self.model.eval()
        with torch.no_grad():
            _, Cls = self.model(test_data_tensor)
            y_pred_tensor_test = torch.max(Cls, 1)[1]
            test_acc = float((y_pred_tensor_test == test_label_tensor).cpu().numpy().astype(int).sum()) / float(
                test_label_tensor.size(0))

            Y_true = test_label_tensor.cpu()
            Y_pred = y_pred_tensor_test.cpu()

        print(f'Final test accuracy for subject {self.nSub} is: {test_acc:.6f}')
        self.log_write.write(f'Final test accuracy is: {test_acc}\n')

        return test_acc, Y_true, Y_pred


def main():
    best_all_subs = []
    # 修改文件名以反映其内容
    result_write = open("./final_test_accuracies.txt", "w")

    for i in range(9):
        subject_num = i + 1
        print(f'\n{"-" * 20} Training for Subject {subject_num} {"-" * 20}')

        # 固定的随机种子，保证每次运行结果一致
        seed_n = 42
        random.seed(seed_n)
        np.random.seed(seed_n)
        torch.manual_seed(seed_n)
        torch.cuda.manual_seed(seed_n)
        torch.cuda.manual_seed_all(seed_n)

        trainer = Trainer(subject_num)
        # bestAcc 现在是最终的测试集准确率
        bestAcc, _, _ = trainer.train()

        best_all_subs.append(bestAcc)
        result_write.write(f'Subject {subject_num}: Final Test Accuracy = {bestAcc:.6f}\n')

    avg_best_acc = np.mean(best_all_subs)
    std_acc = np.std(best_all_subs)  # 新增计算标准差

    print(f'\n{"=" * 20} FINAL SUMMARY {"=" * 20}')
    print(f'Average Test Accuracy across all subjects: {avg_best_acc:.6f}')
    print(f'Standard Deviation of accuracies: {std_acc:.6f}')

    result_write.write(f'\n{"-" * 20}\n')
    result_write.write(f'Average Best accuracy is: {avg_best_acc:.6f}\n')
    result_write.write(f'Standard Deviation is: {std_acc:.6f}\n')  # 新增写入标准差
    result_write.close()


if __name__ == "__main__":
    main()