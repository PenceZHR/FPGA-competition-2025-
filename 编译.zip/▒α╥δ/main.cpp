#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <numeric>
#include <algorithm>
#include <experimental/filesystem>
namespace fs = std::experimental::filesystem;
#include <iomanip>    // 用于格式化输出

#include <onnxruntime_cxx_api.h>

// --- ==================================================================== ---
// --- 关键配置: 从您的Python训练脚本中找到的真实均值和标准差 ---
// --- ==================================================================== ---
const float DATA_MEAN = -0.004831738f;
const float DATA_STD = 5.3116633f;
// --- ==================================================================== ---


/**
 * @brief 对输入的EEG数据进行标准化预处理
 */
void preprocess(std::vector<float>& data) {
    for (auto& val : data) {
        val = (val - DATA_MEAN) / DATA_STD;
    }
}

/**
 * @brief 从文件中加载EEG数据 (最终修正版 - 读取 1000x22 格式)
 */
bool load_eeg_data_from_file(const std::string& file_path, std::vector<float>& target_vector) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "\n错误: 无法打开数据文件: " << file_path << std::endl;
        return false;
    }

    // 创建临时的2D vector来存储从文件读取的 (1000行 x 22列) 数据
    std::vector<std::vector<float>> transposed_data(1000, std::vector<float>(22));
    std::string line;
    int row_idx = 0;
    while (std::getline(file, line) && row_idx < 1000) {
        std::stringstream ss(line);
        float value;
        int col_idx = 0;
        // 逐行读取，每行应包含22个通道值
        while (ss >> value && col_idx < 22) {
            transposed_data[row_idx][col_idx] = value;
            col_idx++;
        }
        // 验证每行的数据量是否正确
        if (col_idx != 22) {
             std::cerr << "\n错误: 文件 " << file_path << " 的第 " << row_idx + 1 << " 行数据量不正确。期望 22, 实际 " << col_idx << "。" << std::endl;
             return false;
        }
        row_idx++;
    }
    // 验证总行数是否正确
    if (row_idx != 1000) {
        std::cerr << "\n错误: 文件 " << file_path << " 的总行数不正确。期望 1000, 实际 " << row_idx << "。" << std::endl;
        return false;
    }

    // 将2D数据“一维化”并进行“反转置”，以匹配ONNX期望的内存布局
    target_vector.clear();
    target_vector.resize(22 * 1000);
    for (int c = 0; c < 22; ++c) {
        for (int t = 0; t < 1000; ++t) {
            target_vector[c * 1000 + t] = transposed_data[t][c];
        }
    }
    
    return true; // 数据加载和重排成功
}

/**
 * @brief 从文件中加载所有标签 (假设为0-indexed)
 */
bool load_labels_from_file(const std::string& file_path, std::vector<int>& labels) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "错误: 无法打开标签文件: " << file_path << std::endl;
        return false;
    }
    labels.clear();
    int label;
    while (file >> label) {
        labels.push_back(label);
    }
    return true;
}


int main(int argc, char* argv[]) {
    // 检查命令行参数
    if (argc != 3) {
        std::cerr << "用法: " << argv[0] << " <trials_directory_path> <labels_file_path>" << std::endl;
        std::cerr << "示例: " << argv[0] << " ./A01_TEST_TRIALS ./A01_TEST_labels_0_indexed.txt" << std::endl;
        return -1;
    }
    fs::path trials_dir = argv[1];
    std::string labels_file = argv[2];

    std::cout << "--- EEG Conformer 批量推理与验证工具 (带详细输出) ---" << std::endl;

    // 1. 初始化ONNX Runtime环境并加载模型
    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "EEG-Batch-Validator");
    Ort::SessionOptions session_options;
    const char* model_path = "eeg_conformer.fp32.onnx";
    Ort::Session session(nullptr);
    try {
        session = Ort::Session(env, model_path, session_options);
    } catch (const Ort::Exception& e) {
        std::cerr << "错误: 加载ONNX模型失败: " << e.what() << std::endl;
        return -1;
    }
    std::cout << "模型加载成功: " << model_path << std::endl;

    // 2. 加载所有真实标签
    std::vector<int> true_labels;
    if (!load_labels_from_file(labels_file, true_labels)) {
        return -1;
    }
    std::cout << "标签文件加载成功，共 " << true_labels.size() << " 个标签。" << std::endl;

    // 3. 获取并排序所有测试文件
    std::vector<fs::path> trial_files;
    try {
        for (const auto& entry : fs::directory_iterator(trials_dir)) {
            if (fs::is_regular_file(entry.path())) {
                trial_files.push_back(entry.path());
            }
        }
    } catch (const fs::filesystem_error& e) {
        std::cerr << "错误: 无法读取数据目录 '" << trials_dir << "': " << e.what() << std::endl;
        return -1;
    }
    std::sort(trial_files.begin(), trial_files.end()); // 按文件名排序
    
    if (trial_files.empty()) {
        std::cerr << "错误: 在目录 '" << trials_dir << "' 中未找到任何数据文件。" << std::endl;
        return -1;
    }
    if (trial_files.size() != true_labels.size()) {
        std::cerr << "警告: 数据文件数量 (" << trial_files.size() << ") 与标签数量 (" << true_labels.size() << ") 不匹配。将只处理较小数量的样本。" << std::endl;
        // (可选) 可以在这里决定是退出还是继续处理公共部分
        // return -1; 
    }
    size_t num_samples_to_process = std::min(trial_files.size(), true_labels.size());
    std::cout << "发现 " << trial_files.size() << " 个测试数据文件。将处理 " << num_samples_to_process << " 个样本。" << std::endl;

    // 4. 循环执行批量推理
    int correct_predictions = 0;
    long long total_duration_ms = 0;
    std::vector<float> input_tensor_values;

    Ort::AllocatorWithDefaultOptions allocator;
    Ort::AllocatedStringPtr input_name_allocated = session.GetInputNameAllocated(0, allocator);
    Ort::AllocatedStringPtr output_name_allocated = session.GetOutputNameAllocated(0, allocator);
    const char* input_name = input_name_allocated.get();
    const char* output_name = output_name_allocated.get();
    std::vector<int64_t> input_node_dims = {1, 1, 22, 1000};
    auto memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

    std::cout << "\n--- 开始批量推理 ---" << std::endl;
    for (size_t i = 0; i < num_samples_to_process; ++i) {
        std::cout << "\r正在处理: " << i + 1 << "/" << num_samples_to_process << "..." << std::flush;

        // 加载并预处理数据
        if (!load_eeg_data_from_file(trial_files[i].string(), input_tensor_values)) continue;
        preprocess(input_tensor_values);
        
        // 创建张量并推理
        Ort::Value input_tensor = Ort::Value::CreateTensor<float>(memory_info, input_tensor_values.data(), input_tensor_values.size(), input_node_dims.data(), input_node_dims.size());
        
        auto start_time = std::chrono::high_resolution_clock::now();
        auto output_tensors = session.Run(Ort::RunOptions{nullptr}, &input_name, &input_tensor, 1, &output_name, 1);
        auto end_time = std::chrono::high_resolution_clock::now();
        total_duration_ms += std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

        // 获取预测结果
        float* floatarr = output_tensors.front().GetTensorMutableData<float>();
        int predicted_class = std::distance(floatarr, std::max_element(floatarr, floatarr + 4));

        // --- 新增: 打印前五个样本的详细分数 ---
        if (i < 5) {
            std::cout << "\n--- [ 样本 " << i << " 详细结果 ] ---" << std::endl;
            std::cout << "  文件名: " << trial_files[i].filename().string() << std::endl; // 使用 .string() 转换
            std::cout << "  真实标签: " << true_labels[i] << std::endl;
            std::cout << "  原始分数: [";
            for(int j=0; j<4; ++j) {
                std::cout << floatarr[j] << (j == 3 ? "" : ", ");
            }
            std::cout << "]" << std::endl;
            std::cout << "  预测类别: " << predicted_class << std::endl;
        }

        // 与真实标签比对
        if (predicted_class == true_labels[i]) {
            correct_predictions++;
        }
    }

    // 5. 打印最终统计结果
    double accuracy = (static_cast<double>(correct_predictions) / num_samples_to_process) * 100.0;
    double avg_time_ms = static_cast<double>(total_duration_ms) / num_samples_to_process;

    std::cout << "\n\n--- 批量测试完成 ---" << std::endl;
    std::cout << std::fixed << std::setprecision(2); // 设置输出精度为两位小数
    std::cout << "最终准确率: " << accuracy << "% (" << correct_predictions << "/" << num_samples_to_process << " 正确)" << std::endl;
    std::cout << "平均推理耗时: " << avg_time_ms << " 毫秒/样本" << std::endl;

    return 0;
}

