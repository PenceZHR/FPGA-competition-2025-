#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <chrono>
#include <algorithm>
#include <iomanip>
#include <onnxruntime_cxx_api.h>

// 读取 22x1000 个 float32 的二进制文件
// interleaved=true 表示文件按时间交织： [t0:c0..c21, t1:c0..c21, ...]
// interleaved=false 表示文件为通道优先（每个通道连续 1000 个样本的块）：[ch0:1000, ch1:1000, ...]
static bool load_eeg_from_bin(const std::string& path,
                              std::vector<float>& out, bool interleaved=true) {
    std::ifstream fin(path, std::ios::binary | std::ios::ate);
    if (!fin.is_open()) {
        std::cerr << "错误: 无法打开二进制文件: " << path << std::endl;
        return false;
    }
    std::streamsize bytes = fin.tellg();
    fin.seekg(0, std::ios::beg);

    if (bytes % 4 != 0) {
        std::cerr << "错误: 文件字节数不是4的倍数: " << bytes << std::endl;
        return false;
    }
    const size_t n_floats = static_cast<size_t>(bytes) / 4;
    const int C = 22, T = 1000;
    if (n_floats != static_cast<size_t>(C*T)) {
        std::cerr << "错误: 期望 " << (C*T) << " 个 float32，实际为 " << n_floats
                  << "。文件大小应为 88000 字节。" << std::endl;
        return false;
    }

    std::vector<float> raw(n_floats);
    if (!fin.read(reinterpret_cast<char*>(raw.data()), bytes)) {
        std::cerr << "错误: 读取二进制数据失败: " << path << std::endl;
        return false;
    }

    // 模型需要的线性内存布局对应形状 [1,1,22,1000]，即每个通道连续存放其 1000 个时间点：
    // out[c*1000 + t] = value(c,t)
    out.assign(C*T, 0.0f);
    if (interleaved) {
        // 原始是时间交织：index = t*22 + c
        for (int t = 0; t < T; ++t) {
            for (int c = 0; c < C; ++c) {
                out[c*T + t] = raw[t*C + c];
            }
        }
    } else {
        // 原始就是通道块（每通道1000点连续），直接拷贝即可
        out = std::move(raw);
    }
    return true;
}

int main(int argc, char* argv[]) {
    // 用法: ./eeg_one_shot <bin_path> [--layout=il|--layout=cf]
    // --layout=il (default): 时间交织 (interleaved)
    // --layout=cf: 通道优先 (channels-first)
    if (argc < 2 || argc > 3) {
        std::cerr << "用法: " << argv[0] << " <bin_path> [--layout=il|--layout=cf]\n"
                  << "示例: " << argv[0] << " sample_22x1000.bin --layout=il" << std::endl;
        return -1;
    }
    std::string bin_path = argv[1];
    bool interleaved = false;
    if (argc == 3) {
        std::string opt = argv[2];
        if (opt == "--layout=cf") interleaved = false;
        else if (opt == "--layout=il") interleaved = true;
        else {
            std::cerr << "未知参数: " << opt << "  (可用: --layout=il | --layout=cf)" << std::endl;
            return -1;
        }
    }

    // 1) 加载 ONNX 模型
    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "EEG-OneShot");
    Ort::SessionOptions so;
    const char* model_path = "eeg_conformer.fp32.onnx";
    Ort::Session session(nullptr);
    try {
        session = Ort::Session(env, model_path, so);
    } catch (const Ort::Exception& e) {
        std::cerr << "错误: 加载ONNX模型失败: " << e.what() << std::endl;
        return -1;
    }
    std::cout << "模型加载成功: " << model_path << std::endl;

    // 2) 读取单个二进制样本（无归一化）
    std::vector<float> input_tensor_values;
    if (!load_eeg_from_bin(bin_path, input_tensor_values, interleaved)) {
        return -1;
    }
    // 输入形状
    std::vector<int64_t> input_node_dims = {1, 1, 22, 1000};

    // 3) 构造输入并执行一次推理
    Ort::AllocatorWithDefaultOptions allocator;
    Ort::AllocatedStringPtr input_name_alloc = session.GetInputNameAllocated(0, allocator);
    Ort::AllocatedStringPtr output_name_alloc = session.GetOutputNameAllocated(0, allocator);
    const char* input_name = input_name_alloc.get();
    const char* output_name = output_name_alloc.get();

    auto mem_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
        mem_info,
        input_tensor_values.data(),
        input_tensor_values.size(),
        input_node_dims.data(),
        input_node_dims.size()
    );

    auto t0 = std::chrono::high_resolution_clock::now();
    auto outputs = session.Run(Ort::RunOptions{nullptr},
                               &input_name, &input_tensor, 1,
                               &output_name, 1);
    auto t1 = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

    // 4) 读取输出并打印
    float* logits = outputs.front().GetTensorMutableData<float>();
    // 假设 4 类
    int argmax = std::distance(logits, std::max_element(logits, logits + 4));

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "输入文件: " << bin_path
              << "  (布局=" << (interleaved ? "时间交织" : "通道优先") << ")\n";
    std::cout << "logits: [";
    for (int i = 0; i < 4; ++i) {
        std::cout << logits[i] << (i==3 ? "" : ", ");
    }
    std::cout << "]\n";
    std::cout << "预测类别: " << argmax << "\n";
    std::cout << std::setprecision(3)
              << "推理耗时: " << ms << " ms\n";

    return 0;
}
